Come lavorare con il template:
- Scaricare la cartella Template Latex in formato .zip
- Importare la cartella zippata su Overleaf (Nuovo Progetto --> Carica Progetto --> Upload .zip file)
- Andare su Menu (in alto a sinistra) --> Documento Principale e settare main.tex
- Modificare il titolo del documento in main.tex
- Creare un file sezioneX.tex per ogni sezione e importarlo in main.tex
- Aggiornare import.tex su GitHub se modificato

Una volta finito il documento, la cartella da uploaddare su GitHub dovà contenere
- main.tex del documento
- files sezioneX.tex del documento
- pdf esportato del documento
Non serve quindi riuploaddare ogni volta import.tex, frontespizio.tex e loghi